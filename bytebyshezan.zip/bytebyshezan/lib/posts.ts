import { Post } from "./types";

// In production, replace this array with a CMS (Contentlayer, Sanity, MDX files, etc.)
// Keeping it as static data here so the whole pipeline (home, dynamic route,
// sitemap, search) is wired up and works out of the box.
export const posts: Post[] = [
  {
    slug: "nextjs-app-router-seo-guide",
    title: "The Complete Next.js App Router SEO Guide (2026)",
    description:
      "Everything you need to rank fast with the Next.js App Router: metadata, sitemaps, structured data, and Core Web Vitals.",
    category: "Next.js",
    tags: ["nextjs", "seo", "performance"],
    coverImage:
      "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=1200&q=80",
    publishedAt: "2026-06-20",
    readingTime: "8 min read",
    featured: true,
    author: {
      name: "Shezan",
      avatar:
        "https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=200&q=80",
      bio: "Full-stack developer writing about AI, web dev, and performance engineering.",
    },
    headings: [
      { id: "why-app-router", text: "Why the App Router changes SEO", level: 2 },
      { id: "metadata-api", text: "Using the Metadata API", level: 2 },
      { id: "dynamic-metadata", text: "Dynamic metadata per route", level: 3 },
      { id: "sitemaps", text: "Auto-generated sitemaps", level: 2 },
      { id: "core-web-vitals", text: "Core Web Vitals checklist", level: 2 },
    ],
    contentHtml: `
      <h2 id="why-app-router">Why the App Router changes SEO</h2>
      <p>The App Router moves rendering closer to the edge and makes streaming server components the default. For SEO, that means faster Time to First Byte and less client-side JavaScript blocking indexation.</p>
      <h2 id="metadata-api">Using the Metadata API</h2>
      <p>Every route can export a <code>metadata</code> object or a <code>generateMetadata</code> function. This is the cleanest way to control titles, descriptions, canonical URLs, and Open Graph tags per page.</p>
      <pre><code class="language-ts">export async function generateMetadata({ params }) {
  const post = getPostBySlug(params.slug);
  return {
    title: post.title,
    description: post.description,
    openGraph: { images: [post.coverImage] },
  };
}</code></pre>
      <h3 id="dynamic-metadata">Dynamic metadata per route</h3>
      <p>Because <code>generateMetadata</code> runs on the server, you can pull the title and description straight from your CMS or database with zero client JS cost.</p>
      <h2 id="sitemaps">Auto-generated sitemaps</h2>
      <p>Next.js supports a <code>sitemap.ts</code> file convention that builds <code>/sitemap.xml</code> automatically from your data source, so new posts get discovered without manual updates.</p>
      <h2 id="core-web-vitals">Core Web Vitals checklist</h2>
      <p>Use <code>next/image</code> for automatic resizing and lazy loading, self-host fonts with <code>next/font</code>, and keep client components small and isolated to protect your Largest Contentful Paint and Interaction to Next Paint scores.</p>
    `,
  },
  {
    slug: "tailwind-dark-mode-best-practices",
    title: "Tailwind CSS Dark Mode: Best Practices for 2026",
    description:
      "A practical guide to building a flicker-free, accessible dark mode toggle with Tailwind CSS and next-themes.",
    category: "Tailwind CSS",
    tags: ["tailwind", "css", "dark-mode"],
    coverImage:
      "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=1200&q=80",
    publishedAt: "2026-06-15",
    readingTime: "6 min read",
    featured: true,
    author: {
      name: "Shezan",
      avatar:
        "https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=200&q=80",
      bio: "Full-stack developer writing about AI, web dev, and performance engineering.",
    },
    headings: [
      { id: "class-strategy", text: "The class-based strategy", level: 2 },
      { id: "avoiding-flicker", text: "Avoiding the flash of wrong theme", level: 2 },
      { id: "accessible-toggle", text: "Building an accessible toggle", level: 2 },
    ],
    contentHtml: `
      <h2 id="class-strategy">The class-based strategy</h2>
      <p>Set <code>darkMode: "class"</code> in your Tailwind config so theme switching is controlled by a class on the <code>html</code> element instead of the OS preference alone.</p>
      <h2 id="avoiding-flicker">Avoiding the flash of wrong theme</h2>
      <p>Read the stored preference in a tiny inline script before hydration, or use a library like <code>next-themes</code> which handles this for you automatically.</p>
      <h2 id="accessible-toggle">Building an accessible toggle</h2>
      <p>Always expose the toggle as a real <code>button</code> with an <code>aria-label</code>, and swap icons (sun/moon) rather than relying on color alone to communicate state.</p>
    `,
  },
  {
    slug: "micro-niche-blog-ranking-strategy",
    title: "How to Rank a Micro-Niche Blog on Google in Days, Not Months",
    description:
      "A tactical breakdown of technical SEO, content depth, and internal linking for micro-niche sites that need to rank fast.",
    category: "SEO",
    tags: ["seo", "content-strategy", "growth"],
    coverImage:
      "https://images.unsplash.com/photo-1571171637578-41bc2dd41cd2?w=1200&q=80",
    publishedAt: "2026-06-25",
    readingTime: "10 min read",
    featured: true,
    author: {
      name: "Shezan",
      avatar:
        "https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=200&q=80",
      bio: "Full-stack developer writing about AI, web dev, and performance engineering.",
    },
    headings: [
      { id: "pick-the-niche", text: "Picking a winnable micro-niche", level: 2 },
      { id: "technical-foundation", text: "Get the technical foundation right first", level: 2 },
      { id: "content-depth", text: "Depth beats volume", level: 2 },
      { id: "internal-linking", text: "Internal linking for topical authority", level: 2 },
    ],
    contentHtml: `
      <h2 id="pick-the-niche">Picking a winnable micro-niche</h2>
      <p>Target a topic narrow enough that a handful of comprehensive articles can realistically outrank generic competitors.</p>
      <h2 id="technical-foundation">Get the technical foundation right first</h2>
      <p>Clean semantic HTML, a valid sitemap, fast Core Web Vitals, and correct heading hierarchy remove every reason for a crawler to hesitate.</p>
      <h2 id="content-depth">Depth beats volume</h2>
      <p>A handful of exhaustive, well-structured articles tends to outperform dozens of thin posts, especially in a tightly scoped niche.</p>
      <h2 id="internal-linking">Internal linking for topical authority</h2>
      <p>Link related articles to each other with descriptive anchor text so search engines can map the topical cluster you're building.</p>
    `,
  },
  {
    slug: "lucide-react-icon-system",
    title: "Building a Consistent Icon System with Lucide React",
    description:
      "How to standardize icon sizing, stroke width, and color across a Next.js + Tailwind design system using Lucide React.",
    category: "UI/UX",
    tags: ["ui", "design-system", "icons"],
    coverImage:
      "https://images.unsplash.com/photo-1559028012-481c04fa702d?w=1200&q=80",
    publishedAt: "2026-06-10",
    readingTime: "5 min read",
    author: {
      name: "Shezan",
      avatar:
        "https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=200&q=80",
      bio: "Full-stack developer writing about AI, web dev, and performance engineering.",
    },
    headings: [
      { id: "why-lucide", text: "Why Lucide React", level: 2 },
      { id: "wrapper-component", text: "Building a wrapper component", level: 2 },
    ],
    contentHtml: `
      <h2 id="why-lucide">Why Lucide React</h2>
      <p>Lucide ships as tree-shakeable SVG components with a consistent 24px grid, which keeps bundle size small and visuals aligned.</p>
      <h2 id="wrapper-component">Building a wrapper component</h2>
      <p>Wrap icons in a small component that fixes stroke width and default size, so every icon across the site looks intentional rather than accidental.</p>
    `,
  },
];

export function getAllPosts(): Post[] {
  return [...posts].sort(
    (a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
  );
}

export function getFeaturedPosts(): Post[] {
  return getAllPosts().filter((p) => p.featured);
}

export function getPostBySlug(slug: string): Post | undefined {
  return posts.find((p) => p.slug === slug);
}

export function getAllSlugs(): string[] {
  return posts.map((p) => p.slug);
}

export function getCategories(): string[] {
  return Array.from(new Set(posts.map((p) => p.category)));
}

export function getPostsByCategory(category: string): Post[] {
  if (category === "All") return getAllPosts();
  return getAllPosts().filter((p) => p.category === category);
}

export function getRelatedPosts(slug: string, limit = 3): Post[] {
  const current = getPostBySlug(slug);
  if (!current) return [];
  return getAllPosts()
    .filter((p) => p.slug !== slug)
    .filter(
      (p) =>
        p.category === current.category ||
        p.tags.some((t) => current.tags.includes(t))
    )
    .slice(0, limit);
}

export function searchPosts(query: string): Post[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  return getAllPosts().filter(
    (p) =>
      p.title.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q) ||
      p.tags.some((t) => t.toLowerCase().includes(q)) ||
      p.category.toLowerCase().includes(q)
  );
}
