export interface Author {
  name: string;
  avatar: string;
  bio: string;
}

export interface Heading {
  id: string;
  text: string;
  level: 2 | 3 | 4;
}

export interface Post {
  slug: string;
  title: string;
  description: string;
  category: string;
  tags: string[];
  coverImage: string;
  publishedAt: string;
  updatedAt?: string;
  readingTime: string;
  author: Author;
  headings: Heading[];
  contentHtml: string; // pre-rendered semantic HTML for the article body
  featured?: boolean;
}
