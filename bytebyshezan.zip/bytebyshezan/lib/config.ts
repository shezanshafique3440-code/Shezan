export const siteConfig = {
  name: "ByteByShezan",
  title: "ByteByShezan — Web Dev, AI Engineering & Performance",
  description:
    "In-depth articles on Next.js, AI engineering, and web performance, written to be fast, clear, and genuinely useful.",
  url: "https://bytebyshezan.com",
  ogImage: "https://bytebyshezan.com/og-cover.jpg",
  twitterHandle: "@bytebyshezan",
  author: "Shezan",
  locale: "en_US",
};
