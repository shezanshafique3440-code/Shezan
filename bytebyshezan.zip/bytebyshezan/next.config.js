/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    formats: ["image/avif", "image/webp"],
    remotePatterns: [
      { protocol: "https", hostname: "images.unsplash.com" },
      { protocol: "https", hostname: "**.bytebyshezan.com" },
    ],
  },
  compress: true,
  poweredByHeader: false,
};

module.exports = nextConfig;
