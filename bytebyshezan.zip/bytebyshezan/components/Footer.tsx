import Link from "next/link";
import { Github, Linkedin, Mail } from "lucide-react";
import { siteConfig } from "@/lib/config";

export function Footer() {
  return (
    <footer className="border-t border-zinc-200 dark:border-zinc-800">
      <div className="container-wide grid gap-8 py-12 sm:grid-cols-3">
        <div>
          <p className="text-base font-semibold text-zinc-900 dark:text-white">
            {siteConfig.name}
          </p>
          <p className="mt-2 max-w-xs text-sm text-zinc-500 dark:text-zinc-400">
            {siteConfig.description}
          </p>
        </div>

        <nav aria-label="Footer" className="text-sm text-zinc-600 dark:text-zinc-300">
          <p className="mb-3 font-medium text-zinc-900 dark:text-white">Site</p>
          <ul className="space-y-2">
            <li><Link href="/" className="hover:text-brand-600 dark:hover:text-brand-400">Home</Link></li>
            <li><Link href="/about" className="hover:text-brand-600 dark:hover:text-brand-400">About</Link></li>
            <li><Link href="/contact" className="hover:text-brand-600 dark:hover:text-brand-400">Contact</Link></li>
            <li><Link href="/sitemap.xml" className="hover:text-brand-600 dark:hover:text-brand-400">Sitemap</Link></li>
          </ul>
        </nav>

        <div>
          <p className="mb-3 text-sm font-medium text-zinc-900 dark:text-white">Connect</p>
          <div className="flex gap-3">
            <a href="#" aria-label="GitHub" className="flex h-9 w-9 items-center justify-center rounded-lg border border-zinc-200 text-zinc-500 hover:bg-zinc-100 dark:border-zinc-800 dark:hover:bg-zinc-900">
              <Github className="h-4 w-4" />
            </a>
            <a href="#" aria-label="LinkedIn" className="flex h-9 w-9 items-center justify-center rounded-lg border border-zinc-200 text-zinc-500 hover:bg-zinc-100 dark:border-zinc-800 dark:hover:bg-zinc-900">
              <Linkedin className="h-4 w-4" />
            </a>
            <a href="mailto:hello@bytebyshezan.com" aria-label="Email" className="flex h-9 w-9 items-center justify-center rounded-lg border border-zinc-200 text-zinc-500 hover:bg-zinc-100 dark:border-zinc-800 dark:hover:bg-zinc-900">
              <Mail className="h-4 w-4" />
            </a>
          </div>
        </div>
      </div>

      <div className="border-t border-zinc-200 py-6 text-center text-xs text-zinc-500 dark:border-zinc-800 dark:text-zinc-500">
        © {new Date().getFullYear()} {siteConfig.name}. All rights reserved.
      </div>
    </footer>
  );
}
