import Link from "next/link";
import { Terminal } from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";
import { SearchBar } from "./SearchBar";
import { getAllPosts } from "@/lib/posts";

export function Header() {
  const posts = getAllPosts();

  return (
    <header className="sticky top-0 z-50 border-b border-zinc-200 bg-white/80 backdrop-blur dark:border-zinc-800 dark:bg-zinc-950/80">
      <div className="container-wide flex h-16 items-center justify-between gap-4">
        <Link href="/" className="flex shrink-0 items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-600 text-white">
            <Terminal className="h-4 w-4" />
          </span>
          <span className="text-base font-semibold tracking-tight text-zinc-900 dark:text-white">
            Byte<span className="text-brand-600 dark:text-brand-400">By</span>Shezan
          </span>
        </Link>

        <nav aria-label="Primary" className="hidden items-center gap-6 text-sm font-medium text-zinc-600 dark:text-zinc-300 md:flex">
          <Link href="/" className="hover:text-brand-600 dark:hover:text-brand-400">Home</Link>
          <Link href="/about" className="hover:text-brand-600 dark:hover:text-brand-400">About</Link>
          <Link href="/contact" className="hover:text-brand-600 dark:hover:text-brand-400">Contact</Link>
        </nav>

        <div className="flex items-center gap-3">
          <div className="hidden sm:block">
            <SearchBar posts={posts} />
          </div>
          <ThemeToggle />
        </div>
      </div>

      <div className="container-wide pb-3 sm:hidden">
        <SearchBar posts={posts} />
      </div>
    </header>
  );
}
