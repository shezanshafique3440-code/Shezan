"use client";

import { useMemo, useState } from "react";
import { Post } from "@/lib/types";
import { ArticleCard } from "./ArticleCard";

export function ArticleExplorer({ posts, categories }: { posts: Post[]; categories: string[] }) {
  const [active, setActive] = useState("All");
  const allCategories = ["All", ...categories];

  const filtered = useMemo(() => {
    if (active === "All") return posts;
    return posts.filter((p) => p.category === active);
  }, [active, posts]);

  return (
    <section className="container-wide py-14">
      <div className="mb-8 flex items-center justify-between gap-4">
        <h2 className="text-2xl font-bold tracking-tight text-zinc-900 dark:text-white">
          Latest Articles
        </h2>
      </div>

      <div
        role="tablist"
        aria-label="Filter articles by category"
        className="mb-8 flex flex-wrap gap-2"
      >
        {allCategories.map((cat) => (
          <button
            key={cat}
            role="tab"
            aria-selected={active === cat}
            onClick={() => setActive(cat)}
            className={`rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${
              active === cat
                ? "bg-brand-600 text-white"
                : "border border-zinc-200 text-zinc-600 hover:bg-zinc-100 dark:border-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-900"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <p className="text-sm text-zinc-500">No articles in this category yet.</p>
      ) : (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((post, i) => (
            <ArticleCard key={post.slug} post={post} priority={i < 3} />
          ))}
        </div>
      )}
    </section>
  );
}
