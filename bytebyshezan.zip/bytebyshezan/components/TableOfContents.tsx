"use client";

import { useEffect, useState } from "react";
import { List } from "lucide-react";
import { Heading } from "@/lib/types";

export function TableOfContents({ headings }: { headings: Heading[] }) {
  const [activeId, setActiveId] = useState<string>("");

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.find((e) => e.isIntersecting);
        if (visible) setActiveId(visible.target.id);
      },
      { rootMargin: "-100px 0px -70% 0px" }
    );

    headings.forEach((h) => {
      const el = document.getElementById(h.id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, [headings]);

  if (headings.length === 0) return null;

  return (
    <nav
      aria-label="Table of contents"
      className="sticky top-24 hidden max-h-[calc(100vh-8rem)] overflow-y-auto rounded-xl border border-zinc-200 p-4 text-sm dark:border-zinc-800 lg:block"
    >
      <p className="mb-3 flex items-center gap-2 font-semibold text-zinc-900 dark:text-white">
        <List className="h-4 w-4 text-brand-600 dark:text-brand-400" />
        On this page
      </p>
      <ul className="space-y-2 border-l border-zinc-200 dark:border-zinc-800">
        {headings.map((h) => (
          <li
            key={h.id}
            style={{ paddingLeft: h.level === 2 ? "1rem" : h.level === 3 ? "1.75rem" : "2.5rem" }}
          >
            <a
              href={`#${h.id}`}
              className={`block border-l -ml-px pl-3 py-0.5 transition-colors ${
                activeId === h.id
                  ? "border-brand-600 font-medium text-brand-600 dark:border-brand-400 dark:text-brand-400"
                  : "border-transparent text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200"
              }`}
            >
              {h.text}
            </a>
          </li>
        ))}
      </ul>
    </nav>
  );
}
