import Link from "next/link";
import Image from "next/image";
import { Clock } from "lucide-react";
import { Post } from "@/lib/types";

export function ArticleCard({ post, priority = false }: { post: Post; priority?: boolean }) {
  return (
    <article className="group flex flex-col overflow-hidden rounded-xl border border-zinc-200 bg-white transition-shadow hover:shadow-lg dark:border-zinc-800 dark:bg-zinc-900">
      <Link href={`/blog/${post.slug}`} className="relative block aspect-[16/9] w-full overflow-hidden">
        <Image
          src={post.coverImage}
          alt={post.title}
          fill
          priority={priority}
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          className="object-cover transition-transform duration-300 group-hover:scale-105"
        />
      </Link>

      <div className="flex flex-1 flex-col p-5">
        <span className="w-fit rounded-full bg-brand-50 px-2.5 py-1 text-xs font-medium text-brand-700 dark:bg-brand-900/40 dark:text-brand-300">
          {post.category}
        </span>

        <h3 className="mt-3 text-lg font-semibold leading-snug text-zinc-900 dark:text-white">
          <Link href={`/blog/${post.slug}`} className="hover:text-brand-600 dark:hover:text-brand-400">
            {post.title}
          </Link>
        </h3>

        <p className="mt-2 line-clamp-2 text-sm text-zinc-500 dark:text-zinc-400">
          {post.description}
        </p>

        <div className="mt-4 flex items-center gap-3 text-xs text-zinc-500 dark:text-zinc-500">
          <time dateTime={post.publishedAt}>
            {new Date(post.publishedAt).toLocaleDateString("en-US", {
              month: "short",
              day: "numeric",
              year: "numeric",
            })}
          </time>
          <span className="flex items-center gap-1">
            <Clock className="h-3.5 w-3.5" />
            {post.readingTime}
          </span>
        </div>
      </div>
    </article>
  );
}
