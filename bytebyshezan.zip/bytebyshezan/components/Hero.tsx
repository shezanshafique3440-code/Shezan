import { Sparkles } from "lucide-react";

export function Hero() {
  return (
    <section className="border-b border-zinc-200 dark:border-zinc-800">
      <div className="container-wide py-16 sm:py-24">
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-zinc-200 bg-zinc-50 px-3 py-1 text-xs font-medium text-zinc-600 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-300">
            <Sparkles className="h-3.5 w-3.5 text-brand-500" />
            Fresh articles every week
          </span>

          <h1 className="mt-6 text-4xl font-bold tracking-tight text-zinc-900 dark:text-white sm:text-5xl">
            Web Dev, AI Engineering & Performance —{" "}
            <span className="text-brand-600 dark:text-brand-400">explained clearly.</span>
          </h1>

          <p className="mx-auto mt-5 max-w-xl text-base text-zinc-600 dark:text-zinc-400 sm:text-lg">
            ByteByShezan is a micro-niche blog covering Next.js, Tailwind CSS,
            and applied AI engineering — written for developers who want
            depth without the fluff.
          </p>
        </div>
      </div>
    </section>
  );
}
