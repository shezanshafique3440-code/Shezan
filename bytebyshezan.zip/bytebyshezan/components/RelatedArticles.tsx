import Link from "next/link";
import Image from "next/image";
import { Post } from "@/lib/types";

export function RelatedArticles({ posts }: { posts: Post[] }) {
  if (posts.length === 0) return null;

  return (
    <aside aria-labelledby="related-heading" className="rounded-xl border border-zinc-200 p-4 dark:border-zinc-800">
      <h2 id="related-heading" className="mb-4 text-sm font-semibold text-zinc-900 dark:text-white">
        Related Articles
      </h2>
      <ul className="space-y-4">
        {posts.map((post) => (
          <li key={post.slug}>
            <Link href={`/blog/${post.slug}`} className="group flex gap-3">
              <span className="relative h-14 w-20 shrink-0 overflow-hidden rounded-lg">
                <Image src={post.coverImage} alt={post.title} fill sizes="80px" className="object-cover" />
              </span>
              <span>
                <span className="line-clamp-2 text-sm font-medium text-zinc-800 group-hover:text-brand-600 dark:text-zinc-200 dark:group-hover:text-brand-400">
                  {post.title}
                </span>
                <span className="mt-1 block text-xs text-zinc-500">{post.readingTime}</span>
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </aside>
  );
}
