import type { Metadata } from "next";
import Image from "next/image";
import { Code2, Rocket, ShieldCheck } from "lucide-react";
import { siteConfig } from "@/lib/config";

export const metadata: Metadata = {
  title: "About",
  description: `Learn about ${siteConfig.name} and the developer behind it.`,
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <section className="container-prose py-16">
      <h1 className="text-3xl font-bold tracking-tight text-zinc-900 dark:text-white">
        About {siteConfig.name}
      </h1>
      <p className="mt-4 text-zinc-600 dark:text-zinc-400">
        {siteConfig.name} is a micro-niche blog focused on Next.js, Tailwind
        CSS, and applied AI engineering. Every article is written to be
        practical first — code you can actually ship, not just theory.
      </p>

      <div className="mt-10 flex items-center gap-4 rounded-xl border border-zinc-200 p-5 dark:border-zinc-800">
        <Image
          src="https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=200&q=80"
          alt="Shezan, founder of ByteByShezan"
          width={64}
          height={64}
          className="rounded-full"
        />
        <div>
          <p className="font-semibold text-zinc-900 dark:text-white">Shezan</p>
          <p className="text-sm text-zinc-500 dark:text-zinc-400">
            Full-stack developer working across AI engineering, web
            development, and medical billing systems.
          </p>
        </div>
      </div>

      <div className="mt-10 grid gap-6 sm:grid-cols-3">
        <div className="rounded-xl border border-zinc-200 p-5 dark:border-zinc-800">
          <Code2 className="h-5 w-5 text-brand-600 dark:text-brand-400" />
          <p className="mt-3 font-medium text-zinc-900 dark:text-white">Practical code</p>
          <p className="mt-1 text-sm text-zinc-500">Real, working examples — not pseudocode.</p>
        </div>
        <div className="rounded-xl border border-zinc-200 p-5 dark:border-zinc-800">
          <Rocket className="h-5 w-5 text-brand-600 dark:text-brand-400" />
          <p className="mt-3 font-medium text-zinc-900 dark:text-white">Performance-obsessed</p>
          <p className="mt-1 text-sm text-zinc-500">Every article is built the way it's written about: fast.</p>
        </div>
        <div className="rounded-xl border border-zinc-200 p-5 dark:border-zinc-800">
          <ShieldCheck className="h-5 w-5 text-brand-600 dark:text-brand-400" />
          <p className="mt-3 font-medium text-zinc-900 dark:text-white">No fluff</p>
          <p className="mt-1 text-sm text-zinc-500">Straight to the point, with sources you can trust.</p>
        </div>
      </div>
    </section>
  );
}
