export default function Loading() {
  return (
    <div className="container-wide grid gap-6 py-14 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="animate-pulse overflow-hidden rounded-xl border border-zinc-200 dark:border-zinc-800">
          <div className="aspect-[16/9] bg-zinc-200 dark:bg-zinc-800" />
          <div className="space-y-3 p-5">
            <div className="h-4 w-1/3 rounded bg-zinc-200 dark:bg-zinc-800" />
            <div className="h-5 w-full rounded bg-zinc-200 dark:bg-zinc-800" />
            <div className="h-4 w-2/3 rounded bg-zinc-200 dark:bg-zinc-800" />
          </div>
        </div>
      ))}
    </div>
  );
}
