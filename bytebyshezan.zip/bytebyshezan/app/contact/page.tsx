import type { Metadata } from "next";
import { Mail, MapPin } from "lucide-react";
import { ContactForm } from "@/components/ContactForm";
import { siteConfig } from "@/lib/config";

export const metadata: Metadata = {
  title: "Contact",
  description: `Get in touch with the ${siteConfig.name} team.`,
  alternates: { canonical: "/contact" },
};

export default function ContactPage() {
  return (
    <section className="container-prose py-16">
      <h1 className="text-3xl font-bold tracking-tight text-zinc-900 dark:text-white">
        Get in touch
      </h1>
      <p className="mt-4 text-zinc-600 dark:text-zinc-400">
        Questions, feedback, or collaboration ideas — send a message and
        expect a reply within 2 business days.
      </p>

      <div className="mt-8 flex flex-wrap gap-6 text-sm text-zinc-600 dark:text-zinc-400">
        <span className="flex items-center gap-2">
          <Mail className="h-4 w-4 text-brand-600 dark:text-brand-400" />
          hello@bytebyshezan.com
        </span>
        <span className="flex items-center gap-2">
          <MapPin className="h-4 w-4 text-brand-600 dark:text-brand-400" />
          Islamabad, Pakistan
        </span>
      </div>

      <div className="mt-10">
        <ContactForm />
      </div>
    </section>
  );
}
