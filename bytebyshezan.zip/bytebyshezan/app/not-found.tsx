import Link from "next/link";
import { FileQuestion } from "lucide-react";

export default function NotFound() {
  return (
    <div className="container-prose flex flex-col items-center justify-center py-24 text-center">
      <FileQuestion className="h-10 w-10 text-brand-500" />
      <h1 className="mt-4 text-2xl font-bold text-zinc-900 dark:text-white">Page not found</h1>
      <p className="mt-2 text-zinc-500">The article or page you're looking for doesn't exist.</p>
      <Link
        href="/"
        className="mt-6 rounded-lg bg-brand-600 px-5 py-2.5 text-sm font-medium text-white hover:bg-brand-700"
      >
        Back to Home
      </Link>
    </div>
  );
}
