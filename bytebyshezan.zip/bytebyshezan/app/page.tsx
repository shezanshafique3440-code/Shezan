import type { Metadata } from "next";
import { Hero } from "@/components/Hero";
import { ArticleExplorer } from "@/components/ArticleExplorer";
import { getAllPosts, getCategories } from "@/lib/posts";
import { siteConfig } from "@/lib/config";

export const metadata: Metadata = {
  title: "Home",
  description: siteConfig.description,
  alternates: { canonical: "/" },
};

export default function HomePage() {
  const posts = getAllPosts();
  const categories = getCategories();

  return (
    <>
      <Hero />
      <ArticleExplorer posts={posts} categories={categories} />
    </>
  );
}
