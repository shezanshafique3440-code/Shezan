# ByteByShezan

A lightning-fast, SEO-first micro-niche blog built with Next.js 14 (App
Router), Tailwind CSS, and Lucide React.

## Stack
- **Next.js App Router** — server components by default, static generation for every article
- **Tailwind CSS** + `@tailwindcss/typography` for article styling
- **next-themes** for flicker-free dark/light mode
- **Lucide React** for icons

## Folder structure

```
bytebyshezan/
├── app/
│   ├── layout.tsx              # fonts, global metadata, JSON-LD, header/footer
│   ├── page.tsx                 # home page
│   ├── globals.css
│   ├── sitemap.ts               # auto XML sitemap
│   ├── robots.ts                # robots.txt
│   ├── loading.tsx
│   ├── not-found.tsx
│   ├── about/page.tsx
│   ├── contact/page.tsx
│   └── blog/[slug]/page.tsx     # dynamic article route (SSG)
├── components/
│   ├── Header.tsx / Footer.tsx
│   ├── Hero.tsx
│   ├── ArticleCard.tsx / ArticleExplorer.tsx
│   ├── SearchBar.tsx
│   ├── TableOfContents.tsx
│   ├── RelatedArticles.tsx
│   ├── ContactForm.tsx
│   ├── ThemeToggle.tsx / ThemeProvider.tsx
├── lib/
│   ├── posts.ts     # data + query helpers — swap for a real CMS later
│   ├── types.ts
│   └── config.ts    # site name, URL, OG defaults
```

## Getting started

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Swapping in real content

`lib/posts.ts` currently holds static sample articles so every page
(home, dynamic route, sitemap, search) works out of the box. To go to
production, replace it with one of:
- MDX files + `next-mdx-remote` or Contentlayer
- A headless CMS (Sanity, Contentful, Notion API)
- A database (Postgres + Prisma)

As long as `getAllPosts()`, `getPostBySlug()`, etc. keep the same return
shape (`Post[]` / `Post | undefined`), no other file needs to change.

## SEO checklist already wired up
- Per-route `generateMetadata` with canonical URLs, Open Graph, Twitter cards
- `BlogPosting` and `WebSite` JSON-LD structured data
- Auto-generated `/sitemap.xml` and `/robots.txt`
- Semantic HTML (`header`, `main`, `article`, `nav`, `aside`, `footer`)
- Clean H1 → H4 hierarchy enforced per article
- `next/image` with explicit `sizes` for responsive, lazy-loaded images
- Self-hosted, swapped fonts via `next/font` (zero layout shift, no external request)

## Before going live
1. Update `lib/config.ts` with your real domain, OG image, and socials.
2. Add a real `/public/og-cover.jpg` (1200×630) and `/public/favicon.ico`.
3. Point `next.config.js` `remotePatterns` at your actual image host.
4. Wire `ContactForm.tsx` to an API route or a service like Resend/Formspree.
5. Submit `sitemap.xml` to Google Search Console once deployed.
